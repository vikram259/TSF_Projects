# Spark--Assignment-1
This file contain spark foundation Assisment 1 solution with Linear Regression Technique.

Problem Statement:
Predict the percentage of an student based on the no. of study hours. What will be predicted score if a student studies for 9.25 hrs./day?

Dataset: http://bit.ly/w-data

